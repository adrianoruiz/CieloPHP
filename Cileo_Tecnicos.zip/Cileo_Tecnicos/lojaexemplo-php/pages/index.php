<html>
	<head>
		<title>Loja Exemplo : Menu</title>
	</head>
	<center>
		<h2>
			Menu
		</h2>
		<h4>
			<a href="carrinho.php">Nova compra</a>
			<br>
			<a href="carrinhoCartao.php">Nova compra (cart�o na loja)</a>
			<br>
			<a href="pedidos.php">Pedidos efetuados</a>
			<br>
			<a href="gerenciarTransacao.php">Gerenciar Transa��o</a>
		</h4>
	</center>
</html>