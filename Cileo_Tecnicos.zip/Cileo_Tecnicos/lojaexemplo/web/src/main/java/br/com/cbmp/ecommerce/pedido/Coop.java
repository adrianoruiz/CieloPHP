package br.com.cbmp.ecommerce.pedido;

/**
 * <p>Proposta</p>
 * 
 * <ol>
 * 		<li>Esclarecer qual � a nova estrat�gia</li>
 * 		<li></li>
 * 		<li>Defini��o de or�amento espec�fico</li>
 * 		<li>Emprego do mapa estrat�gico para possibilitar a vincula��o das inicitivas</li>
 * 		<li>Prioriza��o de iniciativas</li>
 * </ol>
 * 
 * <a href="www.terra.com.br">ABC</a>
 * 
 * @author Marcos Shigueru
 *
 */
public class Coop {
	


}
